import socket

HOST = "coffee.fordhamcss.org"
#YOU NEED TO FIGURE OUT THE PORT USING NMAP
PORT = 0000

s = socket.socket()
s.connect((HOST, PORT))

msgs = '''000055aa000000010000000a00000058dfe853b431f59e520c95a0dbbe6064a21959a31df6788d71dad43340083a1638904c1a03a05cb1bd79d4e0d6672291951959a31df6788d71dad43340083a1638392902a550921e67df43ffdfeeb08901d059175f0000aa55
REMOVE THIS AND INSERT YOUR NEXT MESSAGE HERE
'''

#loop through each line in msgs

for line in msgs.split('\n'):
    if line == "":
        continue

    #converts the hex string into a byte array
    s.send(bytearray.fromhex(line.strip()))
    
    data = s.recv(1024)# receive response
    #print the received response
    print('Received from server: ' + ''.join([str(hex(x))[2:] for x in data])) 